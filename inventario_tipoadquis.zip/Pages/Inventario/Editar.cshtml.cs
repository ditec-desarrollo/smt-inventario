using InventarioSmt.Data;
using InventarioSmt.Servicios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace InventarioSmt.Pages.Inventario;

public class EditarModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly FotoService _fotos;
    private readonly SesionUsuario _sesion;

    public EditarModel(AppDbContext db, FotoService fotos, SesionUsuario sesion)
    {
        _db = db;
        _fotos = fotos;
        _sesion = sesion;
    }

    [BindProperty]
    public Models.Inventario Bien { get; set; } = new();

    [BindProperty]
    public List<IFormFile> Fotos { get; set; } = new();

    public bool EsAlta => Bien.Id == 0;
    public SelectList Estados { get; private set; } = default!;
    public SelectList TiposInstrumento { get; private set; } = default!;
    public SelectList TiposComprobante { get; private set; } = default!;
    public SelectList TiposAutorizacion { get; private set; } = default!;

    /// <summary>Códigos de repartición para los combos; el valor es el código como texto.</summary>
    public List<SelectListItem> Reparticiones { get; private set; } = new();

    public List<SelectListItem> TiposAdquisicion { get; private set; } = new();

    public List<SelectListItem> Rendidos { get; } = new()
    {
        new SelectListItem("0 - No rendido", "0"),
        new SelectListItem("1 - Rendido", "1")
    };

    /// <summary>Nombre del empleado del legajo cargado; se muestra pero no se guarda.</summary>
    public string NombreLegajo { get; private set; } = string.Empty;

    public string? Aviso { get; private set; }

    public async Task<IActionResult> OnGetAsync(int? id)
    {
        if (id.HasValue)
        {
            var bien = await _db.Inventario.FirstOrDefaultAsync(i => i.Id == id);
            if (bien is null) return NotFound();
            Bien = bien;
            Bien.Reparticion = FormatoHelper.SinDecimales(Bien.Reparticion);
        }
        else
        {
            Bien.FechaAlta = DateTime.Today;
            Bien.Cantidad = 1;
        }

        await CargarCatalogosAsync();
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (Bien.Legajo != 0 && !await _db.Legajos.AnyAsync(l => l.Numero == Bien.Legajo))
        {
            ModelState.AddModelError(
                "Bien.Legajo",
                $"El legajo {Bien.Legajo} no existe en la tabla de legajos.");
        }

        if (!ModelState.IsValid)
        {
            await CargarCatalogosAsync();
            return Page();
        }

        if (EsAlta)
        {
            _db.Inventario.Add(Bien);
        }
        else
        {
            var existe = await _db.Inventario.AnyAsync(i => i.Id == Bien.Id);
            if (!existe) return NotFound();
            _db.Inventario.Update(Bien);
        }

        await _db.SaveChangesAsync();

        var errores = new List<string>();
        foreach (var archivo in Fotos.Where(f => f.Length > 0))
        {
            var r = await _fotos.GuardarAsync(Bien.Id, archivo, _sesion.Cuil);
            if (!r.Ok && r.Error is not null) errores.Add($"{archivo.FileName}: {r.Error}");
        }

        TempData["Mensaje"] = errores.Count == 0
            ? "El bien se guardó correctamente."
            : "El bien se guardó, pero algunas fotos no pudieron cargarse: " + string.Join(" ", errores);

        return RedirectToPage("Detalle", new { id = Bien.Id });
    }

    /// <summary>Devuelve el nombre del empleado al escribir el número de legajo.</summary>
    public async Task<IActionResult> OnGetLegajoAsync(int legajo)
    {
        var encontrado = await _db.Legajos
            .Where(l => l.Numero == legajo)
            .Select(l => new { legajo = l.Numero, nombre = l.Nombre })
            .FirstOrDefaultAsync();

        return new JsonResult(encontrado);
    }

    /// <summary>Búsqueda de legajos por nombre para el popup.</summary>
    public async Task<IActionResult> OnGetBuscarLegajosAsync(string? nombre)
    {
        var texto = (nombre ?? string.Empty).Trim();
        if (texto.Length < 2) return new JsonResult(Array.Empty<object>());

        var resultados = await _db.Legajos
            .Where(l => l.Nombre.Contains(texto))
            .OrderBy(l => l.Nombre)
            .Take(50)
            .Select(l => new { legajo = l.Numero, nombre = l.Nombre, dni = l.Dni })
            .ToListAsync();

        return new JsonResult(resultados);
    }

    private async Task CargarCatalogosAsync()
    {
        Estados = new SelectList(await _db.Estados.OrderBy(e => e.Detalle).ToListAsync(), "Codigo", "Detalle");
        TiposInstrumento = new SelectList(await _db.TiposInstrumento.OrderBy(e => e.Detalle).ToListAsync(), "Codigo", "Detalle");
        TiposComprobante = new SelectList(await _db.TiposComprobante.OrderBy(e => e.Detalle).ToListAsync(), "Codigo", "Detalle");
        TiposAutorizacion = new SelectList(await _db.TiposAutorizacion.OrderBy(e => e.Detalle).ToListAsync(), "Codigo", "Detalle");

        Reparticiones = await _db.Reparticiones
            .OrderBy(r => r.Nombre)
            .Select(r => new SelectListItem
            {
                Value = r.Codigo.ToString(),
                Text = r.Codigo + " - " + r.Nombre
            })
            .ToListAsync();

        TiposAdquisicion = await _db.TiposAdquisicion
            .OrderBy(t => t.Detalle)
            .Select(t => new SelectListItem
            {
                Value = t.Codigo.ToString(),
                Text = t.Codigo + " - " + t.Detalle
            })
            .ToListAsync();

        if (Bien.TipoAdquis != 0 && !TiposAdquisicion.Any(t => t.Value == Bien.TipoAdquis.ToString()))
        {
            TiposAdquisicion.Insert(0, new SelectListItem(
                $"{Bien.TipoAdquis} - (valor actual, fuera del catálogo)",
                Bien.TipoAdquis.ToString()));
        }

        // Un bien heredado puede tener códigos que no están en el catálogo:
        // se agregan como opción para no perder el valor al guardar.
        AgregarSiFalta(FormatoHelper.SinDecimales(Bien.Reparticion));
        AgregarSiFalta(Bien.RepOrigen == 0 ? null : Bien.RepOrigen.ToString());
        AgregarSiFalta(Bien.RepDestino == 0 ? null : Bien.RepDestino.ToString());

        if (Bien.Legajo != 0)
        {
            NombreLegajo = await _db.Legajos
                .Where(l => l.Numero == Bien.Legajo)
                .Select(l => l.Nombre)
                .FirstOrDefaultAsync() ?? string.Empty;
        }
    }

    private void AgregarSiFalta(string? codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo)) return;
        if (Reparticiones.Any(r => r.Value == codigo)) return;

        Reparticiones.Insert(0, new SelectListItem(
            $"{codigo} - (valor actual, fuera del catálogo)", codigo));
    }
}
