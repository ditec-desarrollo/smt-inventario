using InventarioSmt.Data;
using InventarioSmt.Servicios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace InventarioSmt.Pages.Inventario;

public class EtiquetaModel : PageModel
{
    private const int BienesPorEtiqueta = 6;

    private readonly AppDbContext _db;
    private readonly QrService _qr;

    public EtiquetaModel(AppDbContext db, QrService qr)
    {
        _db = db;
        _qr = qr;
    }

    public record BienEtiqueta(int Id, string Numero);

    /// <summary>Bienes agrupados según el troquel: cada grupo es una hoja de etiquetas.</summary>
    public List<List<BienEtiqueta>> Etiquetas { get; private set; } = new();

    /// <param name="id">Bien único (ruta), usado desde la pantalla de edición.</param>
    /// <param name="ids">Lista de bienes separados por coma, usada desde el listado.</param>
    public async Task<IActionResult> OnGetAsync(int? id, string? ids)
    {
        var numeros = new List<int>();

        if (id.HasValue) numeros.Add(id.Value);

        if (!string.IsNullOrWhiteSpace(ids))
        {
            numeros.AddRange(ids
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(t => int.TryParse(t, out var n) ? n : 0)
                .Where(n => n > 0));
        }

        numeros = numeros.Distinct().ToList();
        if (numeros.Count == 0) return NotFound();

        var bienes = await _db.Inventario
            .Where(i => numeros.Contains(i.Id))
            .Select(i => new { i.Id, i.Identificacion })
            .ToListAsync();

        if (bienes.Count == 0) return NotFound();

        // Se respeta el orden en que llegaron los identificadores.
        var ordenados = numeros
            .Select(n => bienes.FirstOrDefault(b => b.Id == n))
            .Where(b => b is not null)
            .Select(b => new BienEtiqueta(b!.Id, NumeroEtiqueta(b.Id, b.Identificacion)))
            .ToList();

        Etiquetas = ordenados
            .Select((bien, indice) => new { bien, indice })
            .GroupBy(x => x.indice / BienesPorEtiqueta)
            .Select(g => g.Select(x => x.bien).ToList())
            .ToList();

        return Page();
    }

    /// <summary>Número impreso al lado del QR: 8 dígitos con ceros a la izquierda.</summary>
    private static string NumeroEtiqueta(int id, string? identificacion)
    {
        var texto = FormatoHelper.SinDecimales(identificacion);
        var digitos = new string(texto.Where(char.IsDigit).ToArray());

        if (digitos.Length == 0) digitos = id.ToString();

        return digitos.PadLeft(8, '0');
    }

    /// <summary>Devuelve el PNG del código QR de un bien.</summary>
    public async Task<IActionResult> OnGetQrAsync(int id)
    {
        var bien = await _db.Inventario
            .Where(i => i.Id == id)
            .Select(i => new
            {
                i.Id,
                i.Identificacion,
                i.Equipamiento,
                i.Marca,
                i.Modelo,
                i.NroSerie,
                i.Caracteristicas,
                i.Reparticion,
                i.Oficina
            })
            .FirstOrDefaultAsync();

        if (bien is null) return NotFound();

        var numero = FormatoHelper.SinDecimales(bien.Identificacion);
        if (string.IsNullOrWhiteSpace(numero)) numero = bien.Id.ToString();

        var png = _qr.GenerarPngEtiqueta(QrService.ContenidoBien(
            numero,
            bien.Equipamiento,
            bien.Marca,
            bien.Modelo,
            bien.NroSerie,
            bien.Caracteristicas,
            FormatoHelper.SinDecimales(bien.Reparticion),
            bien.Oficina?.ToString()));

        return File(png, "image/png");
    }
}
