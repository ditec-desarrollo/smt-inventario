using QRCoder;

namespace InventarioSmt.Servicios;

/// <summary>Genera los códigos QR de los bienes como PNG, sin depender de servicios externos.</summary>
public class QrService
{
    public byte[] GenerarPng(string contenido, int pixelesPorModulo = 8)
    {
        using var generador = new QRCodeGenerator();
        using var datos = generador.CreateQrCode(contenido, QRCodeGenerator.ECCLevel.Q);
        var png = new PngByteQRCode(datos);
        return png.GetGraphic(pixelesPorModulo);
    }

    /// <summary>Texto que se codifica en la etiqueta de un bien.</summary>
    public static string ContenidoBien(int id, string? identificacion, string urlDetalle)
    {
        var codigo = string.IsNullOrWhiteSpace(identificacion)
            ? id.ToString()
            : FormatoHelper.SinDecimales(identificacion);

        return $"{urlDetalle}|BIEN:{id}|ID:{codigo}";
    }
}
