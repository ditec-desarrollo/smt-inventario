using InventarioSmt.Data;
using InventarioSmt.Servicios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace InventarioSmt.Pages.Inventario;

public class EtiquetaModel : PageModel
{
    private const int BienesPorEtiqueta = 2;

    private readonly AppDbContext _db;
    private readonly QrService _qr;

    public EtiquetaModel(AppDbContext db, QrService qr)
    {
        _db = db;
        _qr = qr;
    }

    public record BienEtiqueta(int Id, string? Identificacion, string Descripcion, string Reparticion);

    /// <summary>Bienes agrupados de a dos: cada grupo es una etiqueta física.</summary>
    public List<List<BienEtiqueta>> Etiquetas { get; private set; } = new();

    /// <param name="id">Bien único (ruta), usado desde la pantalla de edición.</param>
    /// <param name="ids">Lista de bienes separados por coma, usada desde el listado.</param>
    public async Task<IActionResult> OnGetAsync(int? id, string? ids)
    {
        var numeros = new List<int>();

        if (id.HasValue) numeros.Add(id.Value);

        if (!string.IsNullOrWhiteSpace(ids))
        {
            numeros.AddRange(ids
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(t => int.TryParse(t, out var n) ? n : 0)
                .Where(n => n > 0));
        }

        numeros = numeros.Distinct().ToList();
        if (numeros.Count == 0) return NotFound();

        var bienes = await _db.Inventario
            .Where(i => numeros.Contains(i.Id))
            .Select(i => new
            {
                i.Id,
                i.Identificacion,
                i.Equipamiento,
                i.Marca,
                i.Modelo,
                i.Reparticion
            })
            .ToListAsync();

        if (bienes.Count == 0) return NotFound();

        var codigos = bienes
            .Select(b => int.TryParse(FormatoHelper.SinDecimales(b.Reparticion), out var c) ? c : 0)
            .Where(c => c > 0)
            .Distinct()
            .ToList();

        var reparticiones = await _db.Reparticiones
            .Where(r => codigos.Contains(r.Codigo))
            .ToDictionaryAsync(r => r.Codigo, r => r.Nombre);

        // Se respeta el orden en que llegaron los identificadores.
        var ordenados = numeros
            .Select(n => bienes.FirstOrDefault(b => b.Id == n))
            .Where(b => b is not null)
            .Select(b =>
            {
                var codigo = int.TryParse(FormatoHelper.SinDecimales(b!.Reparticion), out var c) ? c : 0;
                var descripcion = string.Join(' ', new[] { b.Equipamiento, b.Marca, b.Modelo }
                    .Where(t => !string.IsNullOrWhiteSpace(t)));

                return new BienEtiqueta(
                    b.Id,
                    b.Identificacion,
                    descripcion,
                    reparticiones.TryGetValue(codigo, out var nombre) ? nombre : string.Empty);
            })
            .ToList();

        Etiquetas = ordenados
            .Select((bien, indice) => new { bien, indice })
            .GroupBy(x => x.indice / BienesPorEtiqueta)
            .Select(g => g.Select(x => x.bien).ToList())
            .ToList();

        return Page();
    }

    /// <summary>Devuelve el PNG del código QR de un bien.</summary>
    public async Task<IActionResult> OnGetQrAsync(int id)
    {
        var bien = await _db.Inventario
            .Where(i => i.Id == id)
            .Select(i => new { i.Id, i.Identificacion })
            .FirstOrDefaultAsync();

        if (bien is null) return NotFound();

        var urlDetalle = Url.Page("Detalle", null, new { id }, Request.Scheme) ?? $"/Inventario/Detalle/{id}";
        var png = _qr.GenerarPng(QrService.ContenidoBien(bien.Id, bien.Identificacion, urlDetalle));

        return File(png, "image/png");
    }
}
