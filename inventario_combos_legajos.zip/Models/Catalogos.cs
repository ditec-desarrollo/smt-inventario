using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventarioSmt.Models;

[Table("estados")]
public class Estado
{
    [Column("estado")]
    public int Codigo { get; set; }

    [Column("detalle"), StringLength(100)]
    public string? Detalle { get; set; }
}

[Table("tipoinstrumento")]
public class TipoInstrumento
{
    [Column("tipoinst")]
    public int Codigo { get; set; }

    [Column("detalle"), StringLength(50)]
    public string? Detalle { get; set; }
}

[Table("tipocomprobantes")]
public class TipoComprobante
{
    [Column("tipocomp")]
    public int Codigo { get; set; }

    [Column("detalle"), StringLength(10)]
    public string Detalle { get; set; } = string.Empty;
}

[Table("tipoautorizaciones")]
public class TipoAutorizacion
{
    [Column("tipoautoriza")]
    public int Codigo { get; set; }

    [Column("detalle"), StringLength(80)]
    public string? Detalle { get; set; }
}

[Table("reparticiones")]
public class Reparticion
{
    [Column("id")]
    public int Id { get; set; }

    /// <summary>Código de repartición, es la clave que guardan las tablas de inventario.</summary>
    [Column("reparticion")]
    public int Codigo { get; set; }

    [Column("nombre"), StringLength(255)]
    public string Nombre { get; set; } = string.Empty;
}

[Table("legajos")]
public class Legajo
{
    [Column("legajo")]
    public int Numero { get; set; }

    [Column("nombre"), StringLength(100)]
    public string Nombre { get; set; } = string.Empty;

    [Column("dni")]
    public int? Dni { get; set; }

    [Column("reparticion")]
    public int Reparticion { get; set; }

    [Column("nroreg")]
    public long NroReg { get; set; }
}
