using InventarioSmt.Data;
using InventarioSmt.Servicios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace InventarioSmt.Pages.Inventario;

public class EtiquetaModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly QrService _qr;

    public EtiquetaModel(AppDbContext db, QrService qr)
    {
        _db = db;
        _qr = qr;
    }

    public Models.Inventario Bien { get; private set; } = new();
    public string NombreReparticion { get; private set; } = string.Empty;

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var bien = await _db.Inventario.FirstOrDefaultAsync(i => i.Id == id);
        if (bien is null) return NotFound();
        Bien = bien;

        var codigo = FormatoHelper.SinDecimales(bien.Reparticion);
        if (int.TryParse(codigo, out var reparticion))
        {
            NombreReparticion = await _db.Reparticiones
                .Where(r => r.Codigo == reparticion)
                .Select(r => r.Nombre)
                .FirstOrDefaultAsync() ?? string.Empty;
        }

        return Page();
    }

    /// <summary>Devuelve el PNG del código QR del bien.</summary>
    public async Task<IActionResult> OnGetQrAsync(int id)
    {
        var bien = await _db.Inventario
            .Where(i => i.Id == id)
            .Select(i => new { i.Id, i.Identificacion })
            .FirstOrDefaultAsync();

        if (bien is null) return NotFound();

        var urlDetalle = Url.Page("Detalle", null, new { id }, Request.Scheme) ?? $"/Inventario/Detalle/{id}";
        var png = _qr.GenerarPng(QrService.ContenidoBien(bien.Id, bien.Identificacion, urlDetalle));

        return File(png, "image/png");
    }
}
