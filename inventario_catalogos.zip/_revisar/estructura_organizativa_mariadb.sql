-- ---------------------------------------------------------------------------
-- Estructura organizativa (esquema definitivo provisto por el usuario).
-- Jerarquía: repartición > departamento > sección > subsección > oficina.
-- Cada nivel tiene un id autoincremental propio y un código funcional único
-- dentro de su padre.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `departamentos` (
  `id_departamento` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `reparticion` INT(11) NOT NULL,
  `coddep` INT(11) NOT NULL,
  `detalle` VARCHAR(200) NULL DEFAULT NULL,
  PRIMARY KEY (`id_departamento`) USING BTREE,
  UNIQUE INDEX `uk_departamentos` (`reparticion`, `coddep`) USING BTREE
) COLLATE='latin1_swedish_ci' ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `secciones` (
  `id_seccion` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_departamento` INT(10) UNSIGNED NOT NULL,
  `seccion` INT(11) NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id_seccion`) USING BTREE,
  UNIQUE INDEX `uk_secciones` (`id_departamento`, `seccion`) USING BTREE,
  CONSTRAINT `fk_secciones_departamento` FOREIGN KEY (`id_departamento`)
    REFERENCES `departamentos` (`id_departamento`) ON UPDATE CASCADE ON DELETE RESTRICT
) COLLATE='latin1_swedish_ci' ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `subsecciones` (
  `id_subseccion` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_seccion` INT(10) UNSIGNED NOT NULL,
  `subseccion` INT(11) NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id_subseccion`) USING BTREE,
  UNIQUE INDEX `uk_subsecciones` (`id_seccion`, `subseccion`) USING BTREE,
  CONSTRAINT `fk_subsecciones_seccion` FOREIGN KEY (`id_seccion`)
    REFERENCES `secciones` (`id_seccion`) ON UPDATE CASCADE ON DELETE RESTRICT
) COLLATE='latin1_swedish_ci' ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `oficinas` (
  `id_oficina` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_subseccion` INT(10) UNSIGNED NOT NULL,
  `oficina` INT(11) NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id_oficina`) USING BTREE,
  UNIQUE INDEX `uk_oficinas` (`id_subseccion`, `oficina`) USING BTREE,
  CONSTRAINT `fk_oficinas_subseccion` FOREIGN KEY (`id_subseccion`)
    REFERENCES `subsecciones` (`id_subseccion`) ON UPDATE CASCADE ON DELETE RESTRICT
) COLLATE='latin1_swedish_ci' ENGINE=InnoDB;
