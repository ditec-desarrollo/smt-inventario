using InventarioSmt.Servicios.Catalogos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InventarioSmt.Pages.Catalogos;

public class EditarModel : PageModel
{
    private readonly CatalogoService _catalogos;

    public EditarModel(CatalogoService catalogos) => _catalogos = catalogos;

    [BindProperty(SupportsGet = true)]
    public string Catalogo { get; set; } = string.Empty;

    /// <summary>Valor de la clave primaria cuando se edita; vacío en el alta.</summary>
    [BindProperty(SupportsGet = true)]
    public string? Clave { get; set; }

    [BindProperty]
    public Dictionary<string, string?> Valores { get; set; } = new();

    public CatalogoDefinicion Definicion { get; private set; } = default!;
    public Dictionary<string, List<(string Valor, string Texto)>> Opciones { get; private set; } = new();
    public string? Error { get; private set; }

    public bool EsAlta => string.IsNullOrWhiteSpace(Clave);

    public async Task<IActionResult> OnGetAsync()
    {
        var def = Servicios.Catalogos.Catalogo.Buscar(Catalogo);
        if (def is null) return NotFound();
        Definicion = def;

        if (!EsAlta)
        {
            var fila = await _catalogos.ObtenerAsync(def, Clave!, HttpContext.RequestAborted);
            if (fila is null) return NotFound();

            foreach (var campo in def.Campos)
            {
                fila.TryGetValue(campo.Columna, out var valor);
                Valores[campo.Columna] = CatalogoService.ValorCrudo(valor);
            }
        }
        else
        {
            foreach (var campo in def.Campos)
            {
                Valores[campo.Columna] = campo.Tipo == TipoCampo.Estado ? "0" : string.Empty;
            }
        }

        await CargarOpcionesAsync(def);
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var def = Servicios.Catalogos.Catalogo.Buscar(Catalogo);
        if (def is null) return NotFound();
        Definicion = def;

        foreach (var campo in def.Editables)
        {
            var valor = (Valores.TryGetValue(campo.Columna, out var v) ? v : null)?.Trim();

            if (campo.Requerido && string.IsNullOrWhiteSpace(valor))
            {
                ModelState.AddModelError($"Valores[{campo.Columna}]", $"{campo.Etiqueta} es obligatorio.");
            }

            if (campo.Tipo is TipoCampo.Entero or TipoCampo.Estado
                && !string.IsNullOrWhiteSpace(valor) && !long.TryParse(valor, out _))
            {
                ModelState.AddModelError($"Valores[{campo.Columna}]", $"{campo.Etiqueta} debe ser un número.");
            }
        }

        if (!ModelState.IsValid)
        {
            await CargarOpcionesAsync(def);
            return Page();
        }

        var error = await _catalogos.GuardarAsync(def, Valores, EsAlta, Clave, HttpContext.RequestAborted);
        if (error is not null)
        {
            Error = error;
            await CargarOpcionesAsync(def);
            return Page();
        }

        TempData["Mensaje"] = EsAlta ? "El registro se agregó." : "El registro se actualizó.";
        return RedirectToPage("Lista", new { catalogo = Catalogo });
    }

    private async Task CargarOpcionesAsync(CatalogoDefinicion def)
    {
        foreach (var nombre in def.Campos.Where(c => c.Lookup is not null)
                     .Select(c => c.Lookup!).Distinct())
        {
            Opciones[nombre] = await _catalogos.OpcionesAsync(nombre, HttpContext.RequestAborted);
        }
    }
}
